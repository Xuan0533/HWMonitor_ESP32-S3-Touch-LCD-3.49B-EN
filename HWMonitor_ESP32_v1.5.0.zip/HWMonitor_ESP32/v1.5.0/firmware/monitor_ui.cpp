#include <Arduino.h>
#include <lvgl.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// PCM3 field order must match pc/agent.py. All LVGL calls are in the official LVGL task.
enum Field { CPU, CT, CP, CCD0, CCD1, CV, CLK, SOC, GPU, GT, GP, GC, GM, GUSED, GTOTAL, RAM, RTOTAL, PUMP, FAN, SSD, DIMM, WHEA, KP41, LHM, GV, GMC, ECLK, VRM, SYS, CHIP, D1, D3, FCHIP, FEZ, FS1, FS2, FS3, FS4, FS5, FS6, V12, V5, V33, SOD, COUNT };
static_assert(COUNT==44,"PCM3 field count");
static float v[COUNT], hist[2][60];
static uint32_t lastRx=0,lastHistory=0; static bool received=false;
static char line[1024]; static size_t used=0; static bool overflow=false; static bool ackPending=false;
static int page=0, historyPos=0;
static lv_obj_t *root,*body,*status,*tabs[4],*labels[24];
static unsigned nlabels=0;
#if LV_USE_CHART
static lv_obj_t *chart; static lv_chart_series_t *series[2];
#else
#error "PCMonitor 1.3 requires LV_USE_CHART=1 in the official LVGL 9 configuration."
#endif
static const uint32_t cyan=0x65c9ff, green=0xa3e66b, purple=0xcab3ff, white=0xf3f6fa, muted=0x99a5b5, red=0xff7777, bg=0x101419, panelBg=0x1b222b;
static const lv_font_t *largeFont(){
#if LV_FONT_MONTSERRAT_24
 return &lv_font_montserrat_24;
#elif LV_FONT_MONTSERRAT_20
 return &lv_font_montserrat_20;
#else
 return LV_FONT_DEFAULT;
#endif
}
static const lv_font_t *smallFont(){
#if LV_FONT_MONTSERRAT_12
 return &lv_font_montserrat_12;
#else
 return LV_FONT_DEFAULT;
#endif
}
static lv_obj_t *panel(lv_obj_t *p,int x,int y,int w,int h,uint32_t color=panelBg){
 auto *o=lv_obj_create(p);lv_obj_remove_style_all(o);lv_obj_set_pos(o,x,y);lv_obj_set_size(o,w,h);lv_obj_set_style_bg_color(o,lv_color_hex(color),0);lv_obj_set_style_bg_opa(o,LV_OPA_COVER,0);lv_obj_set_style_radius(o,5,0);lv_obj_clear_flag(o,LV_OBJ_FLAG_SCROLLABLE);return o;
}
static lv_obj_t *txt(lv_obj_t *p,int x,int y,const char *s,uint32_t color=white,const lv_font_t *font=LV_FONT_DEFAULT){
 auto *o=lv_label_create(p);lv_obj_set_pos(o,x,y);lv_obj_set_style_text_font(o,font,0);lv_obj_set_style_text_color(o,lv_color_hex(color),0);lv_label_set_text(o,s);return o;
}
static void val(lv_obj_t *p,int x,int y,const lv_font_t *font=LV_FONT_DEFAULT){labels[nlabels++]=txt(p,x,y,"--",white,font);}
static void tile(int i,const char *name,uint32_t color,bool compact=false){auto *p=panel(body,4+(i%4)*159,1+(i/4)*68,154,64);txt(p,8,5,name,muted,smallFont());val(p,8,26,compact?LV_FONT_DEFAULT:largeFont());lv_obj_set_style_text_color(labels[nlabels-1],lv_color_hex(color),0);}
static void rowMetric(lv_obj_t *p,int x,int y,int w,const char *name){txt(p,x,y,name,muted,smallFont());val(p,x+w,y,smallFont());}
static bool online(){return received&&(uint32_t)(millis()-lastRx)<3500;}
static float get(int i){return online()?v[i]:NAN;}
static void fmt(unsigned i,float a,const char *format,uint32_t color=white){char s[48];if(isfinite(a))snprintf(s,sizeof(s),format,(double)a);else strcpy(s,"--");lv_label_set_text(labels[i],s);lv_obj_set_style_text_color(labels[i],lv_color_hex(color),0);}
static void pair(unsigned i,float a,float b){char s[40];if(isfinite(a)&&isfinite(b))snprintf(s,sizeof(s),"%.1f / %.1f GiB",(double)a,(double)b);else strcpy(s,"--");lv_label_set_text(labels[i],s);}
static void makechart(lv_obj_t *p){
 chart=lv_chart_create(p);lv_obj_set_pos(chart,8,37);lv_obj_set_size(chart,318,82);lv_chart_set_type(chart,LV_CHART_TYPE_LINE);lv_chart_set_point_count(chart,60);lv_chart_set_range(chart,LV_CHART_AXIS_PRIMARY_Y,0,100);lv_chart_set_div_line_count(chart,3,6);lv_obj_set_style_bg_color(chart,lv_color_hex(panelBg),0);lv_obj_set_style_border_width(chart,0,0);lv_obj_set_style_pad_all(chart,0,0);lv_obj_set_style_size(chart,0,0,LV_PART_INDICATOR);series[0]=lv_chart_add_series(chart,lv_color_hex(cyan),LV_CHART_AXIS_PRIMARY_Y);series[1]=lv_chart_add_series(chart,lv_color_hex(green),LV_CHART_AXIS_PRIMARY_Y);
}
static void drawcharts(){if(page!=3)return;for(int k=0;k<2;k++)for(int i=0;i<60;i++){float a=hist[k][(historyPos+i)%60];lv_chart_set_value_by_id(chart,series[k],i,isfinite(a)?(int)constrain(a,0.0f,100.0f):LV_CHART_POINT_NONE);}lv_chart_refresh(chart);}
static void refresh(){
 bool on=online();bool warn=on&&((isfinite(v[WHEA])&&v[WHEA]>0)||(isfinite(v[CT])&&v[CT]>=90)||(isfinite(v[GT])&&v[GT]>=85));
 bool partial=on&&v[LHM]!=2&&(v[LHM]!=1||!isfinite(v[CT])||!isfinite(v[CV])||!isfinite(v[GM]));
 lv_label_set_text(status,!on?"OFFLINE":v[LHM]==2?"DEMO":warn?"CHECK":partial?"PARTIAL":"LIVE");lv_obj_set_style_text_color(status,lv_color_hex(!on||warn?red:partial?purple:green),0);
 if(page==0){fmt(0,get(GT),"%.1f C",green);fmt(1,get(GM),"%.1f C",green);fmt(2,get(GP),"%.1f W",green);fmt(3,get(GV),"%.3f V",green);fmt(4,get(GC),"%.0f MHz");fmt(5,get(GMC),"%.0f MHz");pair(6,get(GUSED),get(GTOTAL));fmt(7,get(GPU),"%.0f%%");}
 if(page==1){fmt(0,get(CT),"%.1f C",cyan);fmt(1,get(CP),"%.1f W",cyan);fmt(2,get(CV),"%.3f V",cyan);fmt(3,get(SOC),"%.3f V",cyan);fmt(4,get(CCD0),"%.1f C");fmt(5,get(CCD1),"%.1f C");fmt(6,get(CLK),"%.0f MHz");fmt(7,get(CPU),"%.0f%%");}
 if(page==2){const int t[]={VRM,SYS,CHIP,D1,D3};for(int i=0;i<5;i++)fmt(i,get(t[i]),"%.1f C");const int f[]={FAN,PUMP,FS1,FS2,FS3,FS4,FS5,FS6};for(int i=0;i<8;i++)fmt(5+i,get(f[i]),"%.0f");fmt(13,get(V12),"%.3f V");fmt(14,get(V5),"%.3f V");fmt(15,get(V33),"%.3f V");}
 if(page==3){fmt(0,get(WHEA),"%.0f",get(WHEA)>0?red:white);fmt(1,get(KP41),"%.0f",get(KP41)>0?red:white);lv_label_set_text(labels[2],!on?"NO DATA":v[LHM]==2?"DEMO":"ONLINE");lv_label_set_text(labels[3],!on?"--":v[LHM]==2?"DEMO":v[LHM]!=1?"MISSING":partial?"PARTIAL":"OK");char s[32];if(received&&isfinite(v[SOD])&&v[SOD]>=0&&v[SOD]<86400){unsigned n=(unsigned)v[SOD];snprintf(s,sizeof(s),"%02u:%02u:%02u",n/3600,n/60%60,n%60);}else strcpy(s,"--:--:--");lv_label_set_text(labels[4],s);if(received)snprintf(s,sizeof(s),"%lu s",(unsigned long)((uint32_t)(millis()-lastRx)/1000));else strcpy(s,"--");lv_label_set_text(labels[5],s);}
}
static void build(int p){page=p;lv_obj_clean(body);nlabels=0;for(int i=0;i<4;i++)lv_obj_set_style_bg_color(tabs[i],lv_color_hex(i==p?0x354a60:0x222b36),0);
 if(p==0){const char *names[]={"GPU CORE TEMP","MEMORY JUNCTION","GPU POWER","GPU VOLTAGE","CORE CLOCK","MEMORY CLOCK","VRAM USED / TOTAL","GPU LOAD"};for(int i=0;i<8;i++)tile(i,names[i],green,i==6);}
 if(p==1){const char *names[]={"CPU TEMP","PACKAGE POWER","VCORE (BOARD)","SOC (BOARD)","CCD1 (TDIE)","CCD2 (TDIE)","AVG CORE CLOCK","CPU UTILIZATION"};for(int i=0;i<8;i++)tile(i,names[i],cyan);}
 if(p==2){auto *a=panel(body,4,1,174,132);auto *b=panel(body,182,1,306,132);auto *c=panel(body,492,1,144,132);txt(a,7,5,"TEMPERATURE",purple,smallFont());const char *t[]={"VRM MOS","SYSTEM","CHIPSET","DIMM #1","DIMM #3"};for(int i=0;i<5;i++)rowMetric(a,7,25+i*20,98,t[i]);txt(b,7,5,"FANS / RPM",purple,smallFont());const char *f[]={"CPU","PUMP","SYS 1","SYS 2","SYS 3","SYS 4","SYS 5","SYS 6"};for(int i=0;i<8;i++)rowMetric(b,7+(i/4)*151,25+(i%4)*25,91,f[i]);txt(c,7,5,"BOARD RAILS",purple,smallFont());const char *r[]={"+12V","+5V","+3.3V"};for(int i=0;i<3;i++)rowMetric(c,7,28+i*29,49,r[i]);}
 if(p==3){auto *a=panel(body,4,1,146,132);auto *b=panel(body,154,1,334,132);auto *c=panel(body,492,1,144,132);txt(a,7,5,"WHEA / SINCE BOOT",purple,smallFont());val(a,7,25,largeFont());txt(a,7,67,"KERNEL 41 / 24H",purple,smallFont());val(a,7,87,largeFont());txt(b,8,5,"LAST 60s  /  LOAD %",muted,smallFont());txt(b,8,21,"CPU",cyan,smallFont());txt(b,55,21,"GPU",green,smallFont());txt(b,200,21,"0 - 100%",muted,smallFont());makechart(b);txt(c,7,5,"LINK / LHM",purple,smallFont());val(c,7,23,smallFont());val(c,77,23,smallFont());txt(c,7,52,"LAST UPDATE (PC)",muted,smallFont());val(c,7,69);txt(c,7,95,"DATA AGE",muted,smallFont());val(c,81,95,smallFont());}
 refresh();drawcharts();
}
static void tab(lv_event_t *e){build((int)(intptr_t)lv_event_get_user_data(e));}
static bool parse(char *s){if(strncmp(s,"PCM3,",5)!=0)return false;float next[COUNT];char *p=s+5;for(int i=0;i<COUNT;i++){char *q=strchr(p,',');if((i<COUNT-1&&!q)||(i==COUNT-1&&q))return false;if(q)*q=0;if(strcmp(p,"-")==0)next[i]=NAN;else{char *end;next[i]=strtof(p,&end);if(end==p||*end||!isfinite(next[i]))return false;}p=q?q+1:nullptr;}memcpy(v,next,sizeof(v));lastRx=millis();received=true;return true;}
static void timer(lv_timer_t *){bool changed=false;for(int n=0;n<4096&&Serial.available();n++){int c=Serial.read();if(c<0)break;if(c=='\n'){if(!overflow){line[used]=0;if(strcmp(line,"PCM3?")==0){if(ackPending&&online())Serial.println("PCM3-ACK");ackPending=false;}else{ackPending=parse(line);changed|=ackPending;}}else ackPending=false;used=0;overflow=false;}else if(c!='\r'){if(used<sizeof(line)-1&&!overflow)line[used++]=(char)c;else overflow=true;}}static bool was=false;bool on=online();uint32_t now=millis();uint32_t steps=(uint32_t)(now-lastHistory)/1000;if(steps){lastHistory+=steps*1000;unsigned n=steps>60?60:steps;for(unsigned i=0;i<n;i++){hist[0][historyPos]=(i+1==n)?get(CPU):NAN;hist[1][historyPos]=(i+1==n)?get(GPU):NAN;historyPos=(historyPos+1)%60;}drawcharts();}if(changed||was!=on||steps)refresh();was=on;}
extern "C" void pc_monitor_ui_init(void){for(auto &a:v)a=NAN;for(auto &h:hist)for(auto &a:h)a=NAN;lastHistory=millis();root=lv_screen_active();lv_obj_clean(root);lv_obj_remove_style_all(root);lv_obj_set_style_bg_color(root,lv_color_hex(bg),0);lv_obj_set_style_bg_opa(root,LV_OPA_COVER,0);lv_obj_clear_flag(root,LV_OBJ_FLAG_SCROLLABLE);const char *names[]={"GPU","CPU","BOARD / RAM","HEALTH"};for(int i=0;i<4;i++){tabs[i]=panel(root,4+113*i,3,108,27,0x222b36);lv_obj_add_flag(tabs[i],LV_OBJ_FLAG_CLICKABLE);auto *l=txt(tabs[i],0,0,names[i],white,smallFont());lv_obj_center(l);lv_obj_clear_flag(l,LV_OBJ_FLAG_CLICKABLE);lv_obj_add_event_cb(tabs[i],tab,LV_EVENT_CLICKED,(void*)(intptr_t)i);}status=txt(root,488,8,"OFFLINE",red);body=panel(root,0,34,640,138,bg);build(0);lv_timer_create(timer,100,nullptr);}
