import json, pathlib, sys, tempfile, types, unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pc'))
import launcher
class Launcher(unittest.TestCase):
    def ports(self, *ports):
        serial=types.ModuleType('serial');tools=types.ModuleType('serial.tools');lp=types.ModuleType('serial.tools.list_ports');lp.comports=lambda:list(ports)
        return patch.dict(sys.modules,{'serial':serial,'serial.tools':tools,'serial.tools.list_ports':lp})
    def port(self,name,vid=0x303a,pid=0x1001):return types.SimpleNamespace(device=name,vid=vid,pid=pid,description='test',hwid='test')
    def test_unique_esp(self):
        with tempfile.TemporaryDirectory() as d, self.ports(self.port('COM3'),self.port('COM9',0x1234)), patch.object(launcher,'CONFIG',pathlib.Path(d)/'config.json'):
            cfg={'port':'COM5','sensor_ids':{'a':'b'}}
            self.assertEqual(launcher.choose_port(cfg),'COM3')
            self.assertEqual(json.loads(launcher.CONFIG.read_text()),{'port':'COM3','sensor_ids':{'a':'b'}})
    def test_missing_board_install_ok(self):
        with self.ports():
            self.assertIsNone(launcher.choose_port({},required=False))
            with self.assertRaises(RuntimeError):launcher.choose_port({})
    def test_multi_preserve_selected(self):
        with self.ports(self.port('COM3'),self.port('COM4')):
            self.assertEqual(launcher.choose_port({'port':'COM4'}),'COM4')
    def test_multiple_prompt(self):
        with tempfile.TemporaryDirectory() as d, self.ports(self.port('COM3'),self.port('COM4')), patch.object(launcher,'CONFIG',pathlib.Path(d)/'config.json'), patch('builtins.input',return_value='com4'):
            self.assertEqual(launcher.choose_port({}),'COM4')
    def test_invalid_selection(self):
        with self.ports(self.port('COM3'),self.port('COM4')),patch('builtins.input',return_value='COM7'):
            with self.assertRaises(RuntimeError):launcher.choose_port({})
if __name__=='__main__':unittest.main()
