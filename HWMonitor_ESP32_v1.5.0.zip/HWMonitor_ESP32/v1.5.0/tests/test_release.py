import pathlib, sys, tempfile, unittest, types, json
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pc'));sys.path.insert(0,str(ROOT))
import agent, launcher, probe, prepare_firmware
class Release(unittest.TestCase):
    def ports(self,*ports):
        serial=types.ModuleType('serial');tools=types.ModuleType('serial.tools');lp=types.ModuleType('serial.tools.list_ports');lp.comports=lambda:list(ports)
        serial.SerialException=OSError
        return serial, {'serial':serial,'serial.tools':tools,'serial.tools.list_ports':lp}
    def port(self,name,serial='ABC',vid=0x303a,pid=0x1001):return types.SimpleNamespace(device=name,vid=vid,pid=pid,serial_number=serial,description='test',hwid='test')
    def test_serial_reenumeration(self):
        s,mods=self.ports(self.port('COM9'),self.port('COM3','OTHER'))
        with tempfile.TemporaryDirectory() as d,patch.dict(sys.modules,mods),patch.object(launcher,'CONFIG',pathlib.Path(d)/'config.json'):
            c={'port':'COM3','screen_serial':'ABC'};self.assertEqual(launcher.choose_port(c,interactive=False),'COM9');self.assertEqual(c['screen_serial'],'ABC')
    def test_unattended_no_wrong_board(self):
        s,mods=self.ports(self.port('COM3','OTHER'))
        with patch.dict(sys.modules,mods),patch('builtins.input',side_effect=AssertionError):
            self.assertIsNone(launcher.choose_port({'port':'COM3','screen_serial':'ABC'},required=False,interactive=False,quiet=True))
    def test_probe_ack(self):
        s,mods=self.ports(self.port('COM3'))
        writes=[]
        class Device:
            def __init__(self,*a,**kw):pass
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def reset_input_buffer(self):pass
            def write(self,b):writes.append(b);return len(b)
            def flush(self):pass
            def readline(self):return b'PCM3-ACK\r\n'
        s.Serial=Device
        with patch.dict(sys.modules,mods):self.assertTrue(probe.probe('COM3',1))
        self.assertEqual(writes[1],b'PCM3?\n');self.assertEqual(len(writes[0].strip().split(b',')),45)
    def test_invalid_flash_port(self):
        s,mods=self.ports(self.port('COM3',vid=1234))
        with patch.dict(sys.modules,mods):self.assertIsNone(probe.find_device('COM3'))
    def test_stage_failure_is_retryable(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d);src=p/'source/Arduino/examples/10_LVGL_V9_Test';src.mkdir(parents=True)
            (src/'user_config.h').write_text('#define EXAMPLE_PIN_NUM_BK_LIGHT (GPIO_NUM_42)\n#define Rotated USER_DISP_ROT_NONO')
            (src/'lvgl_port.c').write_text('void f(){lv_demo_widgets();}');(src/'10_LVGL_V9_Test.ino').write_text('void setup(){Serial.begin(115200);}')
            with self.assertRaises(RuntimeError):prepare_firmware.stage(p/'source',p/'build')
            self.assertFalse((p/'build').exists());self.assertFalse(list(p.glob('.stage-*')))
    def test_valid_zero_fan(self):
        rows=[{'id':'/lpc/nct6687dr/0/fan/10','name':'System Fan #1','type':'Fan','value':0}]
        self.assertEqual(agent.select(rows,{})['fan_sys1'],0)
    def test_version(self):self.assertEqual(agent.VERSION,'1.5.0')
