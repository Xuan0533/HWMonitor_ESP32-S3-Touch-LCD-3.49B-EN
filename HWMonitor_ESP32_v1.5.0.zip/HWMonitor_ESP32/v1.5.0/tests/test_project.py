import pathlib, sys, tempfile, unittest, math, datetime as dt
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'pc'));sys.path.insert(0,str(ROOT))
import agent, prepare_firmware
class Project(unittest.TestCase):
    def test_protocol(self):
        fields=agent.frame(agent.demo(3)).decode().strip().split(',');self.assertEqual(len(fields),45);self.assertEqual(fields[0],'PCM3');self.assertEqual(float(fields[15]),32)
        self.assertEqual(agent.frame({'cpu':math.nan}).decode().split(',')[1],'-')
    def test_mapping(self):
        rows=[dict(id='/amdcpu/0/temperature/0',type='Temperature',name='Core (Tctl/Tdie)',value=60),dict(id='/lpc/x/fan/1',type='Fan',name='Fan #1',value=900)]
        self.assertEqual(agent.select(rows,{})['cpu_temp'],60);self.assertIsNone(agent.select(rows,{})['fan']);self.assertEqual(agent.select(rows,{'sensor_ids':{'fan':'/lpc/x/fan/1'}})['fan'],900)
    def test_extended_mapping(self):
        import json
        cfg=json.loads((ROOT/'config.json').read_text())
        types={'cpu_temp':'Temperature','cpu_power':'Power','ccd1':'Temperature','ccd2':'Temperature','cpu_clock':'Clock','cpu_effective_clock':'Clock','gpu_mem_temp':'Temperature','gpu_voltage':'Voltage','gpu_mem_clock':'Clock','dimm1_temp':'Temperature','dimm3_temp':'Temperature','core_voltage':'Voltage','soc_voltage':'Voltage','fan':'Fan','pump':'Fan','fan_chipset':'Fan','fan_ez':'Fan','vrm_temp':'Temperature','system_temp':'Temperature','chipset_temp':'Temperature','rail12':'Voltage','rail5':'Voltage','rail33':'Voltage'}
        types.update({f'fan_sys{i}':'Fan' for i in range(1,7)})
        rows=[dict(id=v,type=types[k],name=k,value=42 if types[k]!='Fan' else 0) for k,v in cfg['sensor_ids'].items()]
        d=agent.select(rows,cfg)
        self.assertTrue(all(d[k]==(0 if types[k]=='Fan' else 42) for k in types))
        self.assertEqual(d['dimm_temp'],42)
        self.assertEqual(d['fan_sys6'],0)
        self.assertEqual(agent.select([dict(id='/amdcpu/0/temperature/2',name='Core (Tctl/Tdie)',type='Temperature',value=0)],cfg)['cpu_temp'],None)
        self.assertEqual(agent.select([dict(id='/gpu-nvidia/0/voltage/0',name='GPU Core Voltage',type='Voltage',value=.94)],{})['gpu_voltage'],.94)
    def test_protocol_schema(self):
        import re
        enum=re.search(r'enum Field \{([^}]+)\}',(ROOT/'firmware'/'monitor_ui.cpp').read_text()).group(1)
        names=[x.strip() for x in enum.split(',')]
        expected='CPU CT CP CCD0 CCD1 CV CLK SOC GPU GT GP GC GM GUSED GTOTAL RAM RTOTAL PUMP FAN SSD DIMM WHEA KP41 LHM GV GMC ECLK VRM SYS CHIP D1 D3 FCHIP FEZ FS1 FS2 FS3 FS4 FS5 FS6 V12 V5 V33 SOD COUNT'.split()
        self.assertEqual(names,expected)
        self.assertEqual(len(agent.FIELDS),len(names)-1)
        self.assertEqual(agent.FIELDS[24:], 'gpu_voltage gpu_mem_clock cpu_effective_clock vrm_temp system_temp chipset_temp dimm1_temp dimm3_temp fan_chipset fan_ez fan_sys1 fan_sys2 fan_sys3 fan_sys4 fan_sys5 fan_sys6 rail12 rail5 rail33 sample_sod'.split())
        d=agent.demo(3);d['sample_sod']=86399
        f=agent.frame(d);self.assertLess(len(f),1024);self.assertTrue(f.endswith(b'86399.0000\n'))
        self.assertTrue(all(k in d for k in agent.FIELDS))
    def test_log_retention(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp); today=dt.date(2026,11,25)
            files=['telemetry_2026-10-26.csv','telemetry_2026-10-27.csv','DEMO_2026-01-01.csv','telemetry_2026-99-99.csv','notes.csv','agent.log','telemetry_2026-11-25.csv','telemetry_2026-12-01.csv']
            for name in files: (p/name).write_text('test')
            (p/'telemetry_2026-01-01.csv').mkdir()
            self.assertEqual(agent.cleanup_csv(p,today,0),[])
            self.assertEqual(set(agent.cleanup_csv(p,today,30)),{'telemetry_2026-10-26.csv','DEMO_2026-01-01.csv'})
            self.assertTrue(all((p/name).exists() for name in files if name not in {'telemetry_2026-10-26.csv','DEMO_2026-01-01.csv'}))
            self.assertTrue((p/'telemetry_2026-01-01.csv').is_dir())
            for invalid in [-1,2.5,True,'30']:
                with self.assertRaises(ValueError):agent.cleanup_csv(p,today,invalid)
    def test_bridge_snapshot(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'lhm_snapshot.json'
            self.assertEqual(agent.read_bridge(p,100),[])
            row={'id':'/amdcpu/0/temperature/0','name':'Core (Tctl/Tdie)','type':'Temperature','value':61.5}
            p.write_text(json.dumps({'schema':1,'timestamp':100,'sensors':[row,{},None]}))
            self.assertEqual(agent.read_bridge(p,102),[row])
            self.assertEqual(agent.select(agent.read_bridge(p,102),{})['cpu_temp'],61.5)
            self.assertEqual(agent.read_bridge(p,106),[])
            self.assertEqual(agent.read_bridge(p,97),[])
            p.write_text('{');self.assertEqual(agent.read_bridge(p,100),[])
    def test_stage(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp);s=p/'source/Arduino/examples/10_LVGL_V9_Test';s.mkdir(parents=True)
            (s/'user_config.h').write_text('#define EXAMPLE_PIN_NUM_BK_LIGHT (GPIO_NUM_42)\n#define Rotated USER_DISP_ROT_NONO')
            (s/'lvgl_port.c').write_text('void f(){lv_demo_widgets();}')
            (s/'10_LVGL_V9_Test.ino').write_text('void setup(){Serial.begin(115200);}')
            l=p/'source/Arduino/libraries/lvgl9/lvgl';l.mkdir(parents=True);(l/'library.properties').write_text('name=lvgl\nversion=9.3.0\n')
            out=prepare_firmware.stage(p/'source',p/'build');self.assertIn('Serial.setRxBufferSize(4096);', (out/'PCMonitorV2.ino').read_text());self.assertIn('pc_monitor_ui_init();',(out/'lvgl_port.c').read_text());self.assertIn('USER_DISP_ROT_90',(out/'user_config.h').read_text());self.assertTrue((out/'monitor_ui.cpp').exists());self.assertTrue((p/'build/libraries/lvgl/library.properties').exists())
            with self.assertRaises(RuntimeError):prepare_firmware.stage(p/'source',p/'build')
if __name__=='__main__':unittest.main()
