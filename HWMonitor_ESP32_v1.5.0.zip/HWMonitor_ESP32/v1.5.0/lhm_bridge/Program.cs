using System.Diagnostics;
using System.Text.Json;
using LibreHardwareMonitor.Hardware;

// Old single-argument mode remains compatible; supervised mode exits with its parent.
if (args.Length != 1 && args.Length != 3) { Console.Error.WriteLine("Usage: PCMonitor.LhmBridge.exe <snapshot> [<stop file> <parent PID>]"); return 2; }
string target = Path.GetFullPath(args[0]);
string? stop = args.Length == 3 ? Path.GetFullPath(args[1]) : null;
int parentPid = args.Length == 3 ? int.Parse(args[2]) : 0;
Directory.CreateDirectory(Path.GetDirectoryName(target)!);
using var logfile = stop == null ? null : new StreamWriter(Path.Combine(Path.GetDirectoryName(target)!, "bridge.log"), append: true) { AutoFlush = true };
if (logfile != null) Console.SetError(TextWriter.Synchronized(logfile));
try
{
    using var parent = parentPid == 0 ? null : Process.GetProcessById(parentPid);
    using var instance = new FileStream(target + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    string temp = target + ".tmp";
    using var cancellation = new CancellationTokenSource();
    Console.CancelKeyPress += (_, e) => { e.Cancel = true; cancellation.Cancel(); };
    var computer = new Computer { IsCpuEnabled = true, IsGpuEnabled = true,
        IsMemoryEnabled = true, IsMotherboardEnabled = true, IsStorageEnabled = true };
    bool Stopping() => cancellation.IsCancellationRequested || (stop != null && File.Exists(stop)) || (parent != null && parent.HasExited);
    Console.Error.WriteLine($"{DateTimeOffset.Now:O} Bridge starting (PID {Environment.ProcessId}).");
    try
    {
        computer.Open();
        while (!Stopping())
        {
            var rows = new List<object>();
            foreach (var hardware in computer.Hardware) Collect(hardware, rows);
            var snapshot = new { schema = 1, timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0, sensors = rows };
            try
            {
                File.WriteAllBytes(temp, JsonSerializer.SerializeToUtf8Bytes(snapshot));
                File.Move(temp, target, true);
            }
            catch (IOException ex) { Console.Error.WriteLine(ex.Message); }
            cancellation.Token.WaitHandle.WaitOne(1000);
        }
    }
    finally
    {
        try { computer.Close(); }
        finally { try { File.Delete(target); File.Delete(temp); } catch (IOException) { } }
    }
    Console.Error.WriteLine($"{DateTimeOffset.Now:O} Bridge stopped.");
    return 0;
}
catch (Exception ex) { Console.Error.WriteLine($"{DateTimeOffset.Now:O} {ex}"); return 1; }

static void Collect(IHardware hardware, List<object> rows)
{
    try
    {
        hardware.Update();
        foreach (var sensor in hardware.Sensors)
        {
            float? value = sensor.Value;
            if (value.HasValue && !float.IsFinite(value.Value)) value = null;
            rows.Add(new { id = sensor.Identifier.ToString(), name = sensor.Name,
                type = sensor.SensorType.ToString(), value });
        }
    }
    catch (Exception ex) { Console.Error.WriteLine($"{hardware.Name}: {ex.Message}"); }
    foreach (var sub in hardware.SubHardware) Collect(sub, rows);
}
