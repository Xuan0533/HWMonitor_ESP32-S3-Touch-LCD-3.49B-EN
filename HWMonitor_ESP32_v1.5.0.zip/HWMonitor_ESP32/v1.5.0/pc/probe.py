"""Send valid PCM3 demo frame then ask firmware to acknowledge receipt."""
import argparse, time, sys
import agent

def find_device(port):
    from serial.tools.list_ports import comports
    return next((p for p in comports() if p.device.upper()==port.upper() and (p.vid,p.pid)==(0x303A,0x1001)),None)

def probe(port, seconds=20):
    import serial
    deadline=time.monotonic()+seconds
    initial=find_device(port); serial_number=getattr(initial,'serial_number',None)
    while time.monotonic()<deadline:
        try:
            from serial.tools.list_ports import comports
            matches=[p for p in comports() if (p.vid,p.pid)==(0x303A,0x1001)]
            same=[p for p in matches if serial_number and getattr(p,'serial_number',None)==serial_number]
            current=next((p for p in matches if p.device.upper()==port.upper()),None)
            if len(same)==1: current=same[0]
            elif not current and not serial_number and len(matches)==1: current=matches[0]
            if not current: time.sleep(.5);continue
            with serial.Serial(current.device,115200,timeout=.2,write_timeout=1) as dev:
                dev.reset_input_buffer()
                while time.monotonic()<deadline:
                    d=agent.demo(time.monotonic());d['sample_sod']=0
                    dev.write(agent.frame(d));dev.write(b'PCM3?\n');dev.flush()
                    end=time.monotonic()+1.2
                    while time.monotonic()<end:
                        if dev.readline().strip()==b'PCM3-ACK':return True
        except (OSError,serial.SerialException):time.sleep(.5)
    return False

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',required=True);p.add_argument('--identify',action='store_true');a=p.parse_args()
    if a.identify:
        dev=find_device(a.port);print(dev.hwid if dev else 'Not a connected Espressif USB Serial/JTAG port');sys.exit(0 if dev else 1)
    ok=probe(a.port);print('PCM3-ACK received: firmware parsed a test frame.' if ok else 'No ACK. Old firmware does not support ACK; new firmware requires a successful response.')
    sys.exit(0 if ok else 1)
