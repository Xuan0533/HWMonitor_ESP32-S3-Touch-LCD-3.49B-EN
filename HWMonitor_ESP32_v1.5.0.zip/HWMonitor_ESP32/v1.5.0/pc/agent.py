"""PCMonitor V2 Windows collector; no network listener or hardware writes."""
import argparse, csv, datetime as dt, json, math, os, pathlib, threading, time, logging, re
ROOT = pathlib.Path(__file__).resolve().parents[1]
FIELDS = 'cpu cpu_temp cpu_power ccd1 ccd2 core_voltage cpu_clock soc_voltage gpu gpu_temp gpu_power gpu_clock gpu_mem_temp vram_used vram_total ram_used ram_total pump fan ssd_temp dimm_temp whea kp41 lhm gpu_voltage gpu_mem_clock cpu_effective_clock vrm_temp system_temp chipset_temp dimm1_temp dimm3_temp fan_chipset fan_ez fan_sys1 fan_sys2 fan_sys3 fan_sys4 fan_sys5 fan_sys6 rail12 rail5 rail33 sample_sod'.split()
LOG = logging.getLogger('pcmonitor')
VERSION = '1.5.0'

def cleanup_csv(logs, today, retention_days):
    """Delete only dated CSVs created by this collector, never arbitrary files."""
    if type(retention_days) is not int or retention_days < 0:
        raise ValueError('log_retention_days must be a non-negative integer (0 disables cleanup)')
    if retention_days == 0: return []
    removed = []
    for path in pathlib.Path(logs).iterdir():
        m = re.fullmatch(r'(?:telemetry_(?:v3_)?|DEMO_(?:v3_)?)(\d{4}-\d{2}-\d{2})\.csv', path.name)
        if not m or path.is_symlink() or not path.is_file(): continue
        try: date = dt.date.fromisoformat(m.group(1))
        except ValueError: continue
        if (today-date).days >= retention_days:
            try:
                path.unlink(); removed.append(path.name); LOG.info('Expired CSV removed: %s', path.name)
            except OSError as e: LOG.warning('CSV cleanup failed for %s: %s',path.name,e)
    return removed

def acquire_lock(path):
    """A Windows OS-held lock prevents a second continuous collector."""
    if os.name != 'nt': return None
    import msvcrt
    f = path.open('a+b')
    try:
        if f.tell() == 0: f.write(b'0'); f.flush()
        f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        return f
    except OSError:
        f.close(); raise RuntimeError('Another collector is running. Stop it before starting a second instance.')


def number(v):
    try:
        f=float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError, OverflowError): return None

def frame(d):
    vals=[number(d.get(k)) for k in FIELDS]
    out=('PCM3,'+','.join('-' if x is None else format(x,'.4f') for x in vals)+'\n').encode('ascii')
    if len(out)>=1024:raise ValueError('PCM3 frame exceeds firmware receive buffer')
    return out

def select(rows, config):
    def match(key, typ, prefixes, names, reduce=None):
        overrides=config.get('sensor_ids',{})
        if key in overrides:
            if not overrides[key]: return None
            a=[r['value'] for r in rows if r['id']==overrides[key] and r['type'].lower()==typ.lower() and r['value'] is not None]
            return a[0] if len(a)==1 else None
        a=[r['value'] for r in rows if r['type'].lower()==typ.lower() and any(r['id'].lower().startswith(p) for p in prefixes) and r['name'].casefold() in [n.casefold() for n in names] and r['value'] is not None]
        return reduce(a) if a and reduce else a[0] if len(a)==1 else None
    amd=['/amdcpu/','/amd cpu/']; nv=['/nvidiagpu/','/gpu-nvidia/']; board=['/lpc/','/motherboard/']; storage=['/nvme/','/hdd/','/ssd/','/ata/','/scsi/']; memory=['/ram/','/memory/','/dimm/','/spd/']
    spec={
      'cpu_temp':('Temperature',amd,['Core (Tctl/Tdie)','CPU (Tctl/Tdie)','CPU Package','Core (Tdie)']),
      'cpu_power':('Power',amd,['CPU Package','Package','CPU Package Power']),
      'ccd1':('Temperature',amd,['CCD1 (Tdie)','CCD #1','CCD1','Core (CCD1)','Core (CCD1 Tdie)']),
      'ccd2':('Temperature',amd,['CCD2 (Tdie)','CCD #2','CCD2','Core (CCD2)','Core (CCD2 Tdie)']),
      'core_voltage':('Voltage',board,['Vcore','CPU Vcore']),
      'soc_voltage':('Voltage',board,['CPU Northbridge/SoC','SoC Voltage']),
      'cpu_clock':('Clock',amd,['Cores (Average)','Average Core Clock','Core Average']),
      'gpu_temp':('Temperature',nv,['GPU Core']), 'gpu_mem_temp':('Temperature',nv,['GPU Memory Junction','GPU Memory','GPU Memory Temperature']),
      'gpu_power':('Power',nv,['GPU Package','GPU Board Power','GPU Total Board Power']), 'gpu_clock':('Clock',nv,['GPU Core']), 'gpu':('Load',nv,['GPU Core']),
      'pump':('Fan',board,['PUMP','PUMP_FAN','PUMP_FAN1','Pump Fan','Pump Fan #1']), 'fan':('Fan',board,['CPU Fan','CPU_FAN','CPU_FAN1']),
      'ssd_temp':('Temperature',storage,['Temperature','Drive Temperature','Composite Temperature','Temperature 1'],max),
      'dimm_temp':('Temperature',memory,['Temperature','DIMM Temperature','SPD Hub Temperature'],max),
    }
    spec.update({
      'gpu_voltage':('Voltage',nv,['GPU Core Voltage']),
      'gpu_mem_clock':('Clock',nv,['GPU Memory']),
      'cpu_effective_clock':('Clock',amd,['Cores (Average Effective)','Average Effective Clock']),
      'vrm_temp':('Temperature',board,['VRM MOS']), 'system_temp':('Temperature',board,['System']),
      'chipset_temp':('Temperature',board,['Chipset']),
      'dimm1_temp':('Temperature',memory,['DIMM #1']), 'dimm3_temp':('Temperature',memory,['DIMM #3']),
      'fan_chipset':('Fan',board,['Chipset Fan']), 'fan_ez':('Fan',board,['EZ-Connect Fan']),
      'rail12':('Voltage',board,['+12V']), 'rail5':('Voltage',board,['+5V']), 'rail33':('Voltage',board,['+3.3V']),
    })
    for i in range(1,7):spec[f'fan_sys{i}']=('Fan',board,[f'System Fan #{i}'])
    d={key:match(key,*args) for key,args in spec.items()}
    # Failed low-level access previously reported CPU 0 C, 0 W and null clock.
    # Do not filter real zero RPM / idle load / effective clock.
    for key in ('cpu_temp','cpu_power','cpu_clock','ccd1','ccd2','core_voltage','soc_voltage'):
        if d[key] is not None and d[key]<=0:d[key]=None
    temps=[d[k] for k in ('dimm1_temp','dimm3_temp') if d[k] is not None]
    if 'dimm_temp' not in config.get('sensor_ids',{}) and temps:d['dimm_temp']=max(temps)
    # GPU data sensors in supplied master source are bytes, not MiB. NVML overrides below.
    return d

def read_bridge(path, now=None):
    """Read a complete, fresh local snapshot; never reuse stale sensor values."""
    try:
        snapshot=json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(snapshot,dict) or snapshot.get('schema')!=1: return []
        stamp=number(snapshot.get('timestamp'))
        age=(time.time() if now is None else now)-stamp if stamp is not None else math.inf
        if not -2 <= age <= 5: return []
        rows=snapshot.get('sensors')
        if not isinstance(rows,list): return []
        return [dict(id=r['id'], name=r['name'], type=r['type'], value=number(r.get('value')))
                for r in rows if isinstance(r,dict) and all(isinstance(r.get(k),str) for k in ('id','name','type'))]
    except (OSError, ValueError, TypeError): return []

class LHM:
    def __init__(self, source='bridge'):
        self.source=source; self.wmi=WmiLHM(); self.warned=False
    def read(self):
        if self.source=='wmi': return self.wmi.read()
        rows=read_bridge(ROOT/'logs'/'lhm_snapshot.json')
        if not rows and not self.warned:
            LOG.warning('Local LHM bridge unavailable or stale. Run lhm.ps1 -Build and -Start; missing sensors remain unknown.')
        self.warned=not bool(rows)
        return rows

class WmiLHM:
    def __init__(self): self.conn=None; self.last_error=None
    def read(self):
        try:
            if self.conn is None:
                import win32com.client
                self.conn=win32com.client.GetObject(r'winmgmts:!\\.\root\LibreHardwareMonitor')
            rows=[dict(id=str(s.Identifier),name=str(s.Name),type=str(s.SensorType),value=number(s.Value)) for s in self.conn.ExecQuery('SELECT * FROM Sensor')]
            self.last_error=None
            return rows
        except Exception as e:
            msg=str(e)
            if msg!=self.last_error: LOG.warning('LHM unavailable: %s',msg)
            self.last_error=msg; self.conn=None; return []

class GPU:
    def __init__(self): self.n=None; self.h=None; self.next_try=0
    def read(self):
        try:
            if self.h is None:
                if time.monotonic()<self.next_try:return {}
                self.next_try=time.monotonic()+10
                import pynvml as n
                if self.n is None:n.nvmlInit(); self.n=n
                handles=[n.nvmlDeviceGetHandleByIndex(i) for i in range(n.nvmlDeviceGetCount())]
                def name(h):
                    s=n.nvmlDeviceGetName(h);return s.decode() if isinstance(s,bytes) else s
                self.h=next((h for h in handles if '5090' in name(h)), handles[0] if len(handles)==1 else None)
                if self.h is None: return {}
            n,h=self.n,self.h
            def safe(fn):
                try:return number(fn())
                except Exception:return None
            d={'gpu':safe(lambda:n.nvmlDeviceGetUtilizationRates(h).gpu),'gpu_temp':safe(lambda:n.nvmlDeviceGetTemperature(h,n.NVML_TEMPERATURE_GPU)),'gpu_power':safe(lambda:n.nvmlDeviceGetPowerUsage(h)/1000),'gpu_clock':safe(lambda:n.nvmlDeviceGetClockInfo(h,n.NVML_CLOCK_GRAPHICS)),'vram_used':safe(lambda:n.nvmlDeviceGetMemoryInfo(h).used/2**30),'vram_total':safe(lambda:n.nvmlDeviceGetMemoryInfo(h).total/2**30)}
            if all(x is None for x in d.values()): self.h=None
            return {k:v for k,v in d.items() if v is not None}
        except Exception as e:
            LOG.warning('NVML unavailable: %s',e); self.h=None; return {}
    def close(self):
        if self.n:
            try:self.n.nvmlShutdown()
            except Exception:pass

class Events:
    def __init__(self,boot):
        self.boot=boot; self.data={'whea':None,'kp41':None}; self.ready=threading.Event(); self.stop=threading.Event(); threading.Thread(target=self.run,daemon=True).start()
    def run(self):
        try:import win32evtlog as e
        except ImportError as ex:
            LOG.warning('Event log unavailable: %s',ex);self.ready.set();return
        def count(provider, start, event_id=None):
            # XPath time window in milliseconds; count only matching System records.
            ms=max(0,int((time.time()-start)*1000)); filt=f"Provider[@Name='{provider}'] and TimeCreated[timediff(@SystemTime) <= {ms}]"
            if event_id is not None:filt+=f' and EventID={event_id}'
            h=e.EvtQuery('System',e.EvtQueryChannelPath|e.EvtQueryReverseDirection,f'*[System[{filt}]]'); total=0
            try:
                while True:
                    try: batch=e.EvtNext(h,128)
                    except Exception as ex:
                        if getattr(ex,'winerror',None)==259:break
                        raise
                    if not batch:break
                    total+=len(batch)
                    for event in batch:event.Close()
                return total
            finally:h.Close()
        while not self.stop.is_set():
            d={}
            for key,provider,start,id_ in [('whea','Microsoft-Windows-WHEA-Logger',self.boot,None),('kp41','Microsoft-Windows-Kernel-Power',time.time()-86400,41)]:
                try:d[key]=count(provider,start,id_)
                except Exception as ex:LOG.warning('Event log %s: %s',key,ex);d[key]=None
            self.data=d;self.ready.set();self.stop.wait(15)

class Connection:
    def __init__(self,port,screen_serial=None):self.port=port;self.screen_serial=screen_serial;self.s=None;self.retry=0
    def send(self,data):
        import serial
        if self.s is None and time.monotonic()>=self.retry:
            self.retry=time.monotonic()+3
            try:
                if self.screen_serial:
                    from serial.tools.list_ports import comports
                    matches=[p.device for p in comports() if (p.vid,p.pid)==(0x303A,0x1001) and p.serial_number==self.screen_serial]
                    if len(matches)!=1:return
                    self.port=matches[0]
                self.s=serial.Serial(self.port,115200,timeout=0,write_timeout=.3);LOG.info('Connected %s',self.port)
            except (OSError,serial.SerialException) as e:LOG.warning('Waiting for %s: %s',self.port,e)
        if self.s:
            try:
                if self.s.write(data)!=len(data):raise serial.SerialException("Short serial write")
            except (OSError,serial.SerialException) as e:LOG.warning('Disconnected: %s',e);self.close()
    def close(self):
        if self.s:
            try:self.s.close()
            finally:self.s=None

def demo(t):
    d=dict(zip(FIELDS,[24,62,87,60,53,1.24,4900,1.2,12,48,64,1600,54,8,32,32,96,2800,850,43,42,0,0,2]))
    d.update(gpu_voltage=.94,gpu_mem_clock=7001,cpu_effective_clock=840,vrm_temp=36,system_temp=37.5,chipset_temp=38,dimm1_temp=34.5,dimm3_temp=32.75,fan_chipset=0,fan_ez=0,fan_sys1=996,fan_sys2=1289,fan_sys3=0,fan_sys4=0,fan_sys5=0,fan_sys6=846,rail12=12.096,rail5=5.08,rail33=3.312)
    d['cpu']=40+30*math.sin(t/9);d['gpu']=45+35*math.sin(t/13);return d

def main():
    a=argparse.ArgumentParser();a.add_argument('--version',action='version',version=VERSION);a.add_argument('--background',action='store_true',help=argparse.SUPPRESS);a.add_argument('--port');a.add_argument('--list-ports',action='store_true');a.add_argument('--sensors',action='store_true');a.add_argument('--demo',action='store_true');a.add_argument('--no-serial',action='store_true');a.add_argument('--once',action='store_true');a.add_argument('--parent-pid',type=int,help=argparse.SUPPRESS);a.add_argument('--parent-created',type=float,help=argparse.SUPPRESS);args=a.parse_args()
    from logging.handlers import RotatingFileHandler
    (ROOT/'logs').mkdir(exist_ok=True)
    handlers=[RotatingFileHandler(ROOT/'logs'/'agent.log',maxBytes=1000000,backupCount=3,encoding='utf-8')]
    import sys
    if sys.stderr is not None:handlers.append(logging.StreamHandler())
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=handlers)
    cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8-sig'));port=args.port or cfg.get('port')
    retention=cfg.get('log_retention_days',0)
    if type(retention) is not int or retention<0:a.error('log_retention_days must be a non-negative integer (0 disables cleanup)')
    if args.list_ports:
        from serial.tools.list_ports import comports
        for p in comports():print(p.device,p.description,p.hwid)
        return
    source=cfg.get('lhm_source','bridge')
    if source not in ('bridge','wmi'):a.error('lhm_source must be bridge or wmi')
    lhm=LHM(source)
    if args.sensors:
        rows=lhm.read();print(json.dumps(rows,indent=2,ensure_ascii=False));(ROOT/'sensor_inventory.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf-8');return
    if not (args.no_serial or args.once) and not port:a.error('Use --list-ports, then set port in config.json or --port COMx')
    import psutil
    lock = None if args.once else acquire_lock(ROOT/'logs'/'collector.lock')
    psutil.cpu_percent(None); gpu=GPU();events=Events(psutil.boot_time()) if not args.demo and os.name=='nt' else None
    conn=Connection(port,cfg.get('screen_serial') if not args.port or args.port==cfg.get('port') else None) if port and not(args.no_serial or args.once) else None
    interval=max(.5,min(2,float(cfg.get('interval_seconds',1))))
    logs=ROOT/'logs';logs.mkdir(exist_ok=True);day=None;f=None;cleanup_day=None
    LOG.info('PCMonitor %s started (demo=%s, port=%s)',VERSION,args.demo,port)
    try:
        while True:
            if args.parent_pid is not None:
                try:
                    if args.parent_created is None or abs(psutil.Process(args.parent_pid).create_time()-args.parent_created)>1:break
                except (psutil.NoSuchProcess,psutil.AccessDenied):break
            if args.background and (ROOT/'logs'/'stop.request').exists():
                LOG.info('Scheduled collector stop requested');break
            start=time.monotonic()
            if args.demo:d=demo(start)
            else:
                rows=lhm.read();d=select(rows,cfg);d['lhm']=int(bool(rows));d.update(gpu.read());m=psutil.virtual_memory();d.update(cpu=psutil.cpu_percent(None),ram_used=(m.total-m.available)/2**30,ram_total=m.total/2**30)
                # Average core clock must not be replaced by nominal psutil frequency.
                if events:
                    if args.once:events.ready.wait(3)
                    d.update(events.data)
            now=dt.datetime.now().astimezone();d['sample_sod']=now.hour*3600+now.minute*60+now.second
            for key in FIELDS:d.setdefault(key,None)
            if args.once:print(json.dumps(d,indent=2,allow_nan=False));return
            date=now.strftime('%Y-%m-%d');prefix='DEMO_v3_' if args.demo else 'telemetry_v3_'
            if cfg.get('log_csv',True):
                if cleanup_day!=date:
                    cleanup_csv(logs,now.date(),retention);cleanup_day=date
                if day!=date:
                    if f:f.close()
                    path=logs/(prefix+date+'.csv');new=not path.exists() or not path.stat().st_size;f=path.open('a',encoding='utf-8',newline='');writer=csv.writer(f);day=date
                    if new:writer.writerow(['timestamp']+FIELDS)
                writer.writerow([now.isoformat(timespec='milliseconds')]+[d.get(k) for k in FIELDS]);f.flush()
            if conn:conn.send(frame(d))
            elif args.no_serial and not args.background:print(json.dumps(d,allow_nan=False),flush=True)
            time.sleep(max(0,interval-(time.monotonic()-start)))
    except KeyboardInterrupt:pass
    finally:
        if conn:conn.close()
        if f:f.close()
        if events:events.stop.set()
        gpu.close()
        if lock:lock.close()
if __name__=='__main__':main()
