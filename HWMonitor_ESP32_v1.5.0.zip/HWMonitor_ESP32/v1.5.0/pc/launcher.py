"""One-console supervisor; optional elevated logon mode."""
import argparse, ctypes, json, os, pathlib, subprocess, sys, time
import agent
ROOT = pathlib.Path(__file__).resolve().parents[1]
LOGS = ROOT / 'logs'
CONFIG = ROOT / 'config.json'
BRIDGE = ROOT / 'build_lhm' / 'bridge' / 'PCMonitor.LhmBridge.exe'

def choose_port(config, required=True, interactive=True, quiet=False):
    from serial.tools.list_ports import comports
    ports = list(comports())
    matches = [p for p in ports if (p.vid, p.pid) == (0x303A, 0x1001)]
    old = config.get('port')
    preferred_serial = config.get('screen_serial')
    same = [p for p in matches if preferred_serial and getattr(p,'serial_number',None)==preferred_serial]
    if len(same)==1:
        port=same[0].device
    elif len(matches) == 1 and not preferred_serial:
        port = matches[0].device
        print(f'ESP32 USB Serial/JTAG: {port}', flush=True)
    elif old and not preferred_serial and any(p.device == old for p in matches):
        port = old
    elif matches and required and interactive:
        for p in matches:
            print(p.device, p.description, p.hwid)
        port = input('Screen COM port (blank to cancel): ').strip().upper()
        if not any(p.device.upper() == port for p in matches):
            raise RuntimeError('No matching connected COM port selected.')
    else:
        if required:
            raise RuntimeError('Screen not detected. Connect USB data cable, then run Start.cmd again.')
        if not quiet: print('No unique ESP32 detected. Start.cmd will select the port when connected.')
        return None
    selected=next((p for p in matches if p.device.upper()==port.upper()),None)
    serial_number=getattr(selected,'serial_number',None)
    if port != old or (serial_number and preferred_serial!=serial_number):
        config['port'] = port
        if serial_number: config['screen_serial']=serial_number
        else: config.pop('screen_serial',None)
        tmp = CONFIG.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8')
        tmp.replace(CONFIG)
    return port

def elevate_bridge(stop_path):
    import psutil
    parent = psutil.Process(os.getpid())
    argv = [str(LOGS / 'lhm_snapshot.json'), str(stop_path), str(os.getpid())]
    shell = ctypes.windll.shell32.ShellExecuteW
    shell.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_int]
    shell.restype = ctypes.c_void_p
    rc = shell(None, 'runas', str(BRIDGE), subprocess.list2cmdline(argv), str(BRIDGE.parent), 0)
    if not rc or rc <= 32:
        raise RuntimeError(f'Bridge launch failed or UAC cancelled (ShellExecute={rc}).')
    return parent.create_time()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--configure', action='store_true')
    p.add_argument('--configure-required', action='store_true')
    p.add_argument('--startup', action='store_true')
    a = p.parse_args()
    config = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    if a.startup:
        LOGS.mkdir(exist_ok=True)
        sys.stdout = sys.stderr = open(LOGS / 'startup.log', 'a', encoding='utf-8', buffering=1)
    if a.configure or a.configure_required:
        choose_port(config, required=a.configure_required)
        return
    if os.name != 'nt':
        raise RuntimeError('Windows only.')
    if not BRIDGE.is_file():
        raise RuntimeError('Bridge not built. Run Install.cmd.')
    LOGS.mkdir(exist_ok=True)
    lock = agent.acquire_lock(LOGS / 'launcher.lock')
    stop_agent = LOGS / 'stop.request'
    stop_bridge = LOGS / 'bridge.stop'
    child = None
    bridge_child = None
    launched = False
    try:
        for f in (stop_agent, stop_bridge):
            f.unlink(missing_ok=True)
        if a.startup:
            # A logon task cannot ask questions; wait until the configured/unique board is present.
            port = None
            while not stop_agent.exists() and not stop_bridge.exists():
                port = choose_port(config, required=False, interactive=False, quiet=True)
                if port: break
                time.sleep(2)
            if not port: return
        else:
            port = choose_port(config)
        collector_check=agent.acquire_lock(LOGS / 'collector.lock')
        if collector_check: collector_check.close()
        snapshot = LOGS / 'lhm_snapshot.json'
        # An already active manual bridge in this directory must not be duplicated.
        if agent.read_bridge(snapshot):
            raise RuntimeError('A bridge is already publishing here. Stop the old LHM bridge and retry.')
        print('Starting sensor bridge.' if a.startup else 'Starting sensor bridge. Approve the Windows UAC prompt.', flush=True)
        started = time.time()
        if a.startup:
            import psutil
            if not ctypes.windll.shell32.IsUserAnAdmin():
                raise RuntimeError('Startup task must be elevated.')
            parent_time = psutil.Process(os.getpid()).create_time()
            bridge_child = subprocess.Popen([str(BRIDGE), str(snapshot), str(stop_bridge), str(os.getpid())], cwd=BRIDGE.parent, creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            parent_time = elevate_bridge(stop_bridge)
        launched = True
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if stop_agent.exists() or stop_bridge.exists():
                return
            if bridge_child is not None and bridge_child.poll() is not None: raise RuntimeError("Bridge exited; see logs/bridge.log")
            try:
                record = json.loads(snapshot.read_text(encoding='utf-8-sig'))
                if record.get('timestamp', 0) >= started and agent.read_bridge(snapshot):
                    break
            except (OSError, ValueError, TypeError):
                pass
            time.sleep(.25)
        else:
            raise RuntimeError('No fresh sensor snapshot after 30 seconds. See logs/bridge.log; check PawnIO and UAC.')
        print(f'Starting monitor on {port}. Use Ctrl+C or Stop.cmd to stop both.', flush=True)
        child = subprocess.Popen([sys.executable, str(ROOT / 'pc' / 'agent.py'), '--background', '--port', port,
                                  '--parent-pid', str(os.getpid()), '--parent-created', str(parent_time)],
                                 cwd=ROOT, creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        while child.poll() is None and not stop_agent.exists() and not stop_bridge.exists():
            if bridge_child is not None and bridge_child.poll() is not None: raise RuntimeError("Bridge exited; see logs/bridge.log")
            time.sleep(.25)
        if child.poll() not in (None, 0):
            raise RuntimeError(f'Collector exited with code {child.returncode}; see logs/agent.log.')
    except KeyboardInterrupt:
        print('\nStopping monitor...', flush=True)
    finally:
        if launched:
            stop_agent.touch()
            stop_bridge.touch()
        if child is not None and child.poll() is None:
            try:
                child.wait(timeout=8)
            except subprocess.TimeoutExpired:
                child.terminate()
                child.wait(timeout=5)
        if launched:
            # The bridge closes its hardware handles and removes its snapshot.
            for _ in range(40):
                if not agent.read_bridge(LOGS / 'lhm_snapshot.json'):
                    break
                time.sleep(.25)
        if bridge_child is not None and bridge_child.poll() is None:
            try: bridge_child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                bridge_child.terminate(); bridge_child.wait(timeout=5)
        if lock:
            lock.close()
    print('Monitor stopped.', flush=True)

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'PCMonitor: {e}', file=sys.stderr, flush=True)
        sys.exit(1)
